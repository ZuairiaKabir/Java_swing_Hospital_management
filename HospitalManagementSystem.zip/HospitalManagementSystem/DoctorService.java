package com.example.HospitalManagementSystem;
import java.util.ArrayList;
import java.util.List;

public class DoctorService {
	 private List<Doctor> doctors;

	    public DoctorService() {
	        doctors = new ArrayList<>();
	    }

	    public void registerDoctor(Doctor doctor) {
	        doctors.add(doctor);
	    }

	    public Doctor getDoctor(String name) {
	        for (Doctor doctor : doctors) {
	            if (doctor.getName().equals(name)) {
	                return doctor;
	            }
	        }
	        return null;
	    }
}
