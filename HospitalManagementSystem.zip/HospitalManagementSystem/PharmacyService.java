package com.example.HospitalManagementSystem;

import java.util.List;

public class PharmacyService {
	private Pharmacy pharmacy;

    public PharmacyService() {
        pharmacy = new Pharmacy();
    }

    public void accessPrescriptions(int patientId, List<Prescription> prescriptions) {
        pharmacy.accessPrescriptions(patientId, prescriptions);
    }
}
