package com.example.HospitalManagementSystem;
import java.util.List;
public class CentralHospitalManagementSystem {

	public static void main(String[] args) {
		 // Create services
        PatientService patientService = new PatientService();
        DoctorService doctorService = new DoctorService();
        PharmacyService pharmacyService = new PharmacyService();

        // Register patients
        Patient patient1 = new Patient("John Doe", "No allergies");
        Patient patient2 = new Patient("Jane Smith", "Diabetic");
        patientService.registerPatient(patient1);
        patientService.registerPatient(patient2);

        // Register doctor
        Doctor doctor = new Doctor("Dr. Alice");
        doctorService.registerDoctor(doctor);

        // Doctor writes prescription
        doctor.writePrescription(patient1, "Ibuprofen", "200mg");
        doctor.writePrescription(patient2, "Insulin", "10 units");

        // View patient record
        patientService.viewPatientRecord(patient1.getPatientId());

        // Pharmacy accesses prescriptions
        List<Prescription> prescriptions = doctor.getPrescriptions();
        pharmacyService.accessPrescriptions(patient1.getPatientId(), prescriptions);
        System.out.println();
        patientService.viewPatientRecord(patient2.getPatientId());
        pharmacyService.accessPrescriptions(patient2.getPatientId(), prescriptions);

	}

}
