package com.example.HospitalManagementSystem;

public class Patient {
	 private static int idCounter = 1000;
	    private int patientId;
	    private String name;
	    private String medicalHistory;

	    public Patient(String name, String medicalHistory) {
	        this.patientId = idCounter++;
	        this.name = name;
	        this.medicalHistory = medicalHistory;
	    }

	    public int getPatientId() {
	        return patientId;
	    }

	    public String getName() {
	        return name;
	    }

	    public String getMedicalHistory() {
	        return medicalHistory;
	    }
}
