package com.example.HospitalManagementSystem;
import java.util.ArrayList;
import java.util.List;
public class Doctor {
	 private String name;
	    private List<Prescription> prescriptions;

	    public Doctor(String name) {
	        this.name = name;
	        this.prescriptions = new ArrayList<>();
	    }

	    public String getName() {
	        return name;
	    }

	    public void writePrescription(Patient patient, String medication, String dosage) {
	        Prescription prescription = new Prescription(patient.getPatientId(), medication, dosage);
	        prescriptions.add(prescription);
	    }

	    public List<Prescription> getPrescriptions() {
	        return prescriptions;
	    }
}
