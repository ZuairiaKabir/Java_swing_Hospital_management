package com.example.HospitalManagementSystem;

public class Prescription {
	 private int patientId;
	    private String medication;
	    private String dosage;

	    public Prescription(int patientId, String medication, String dosage) {
	        this.patientId = patientId;
	        this.medication = medication;
	        this.dosage = dosage;
	    }

	    public int getPatientId() {
	        return patientId;
	    }

	    public String getMedication() {
	        return medication;
	    }

	    public String getDosage() {
	        return dosage;
	    }
}
