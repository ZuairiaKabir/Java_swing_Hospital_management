package com.example.HospitalManagementSystem;
import java.util.List;

public class Pharmacy {
	 public void accessPrescriptions(int patientId, List<Prescription> prescriptions) {
	        System.out.println("Prescriptions for Patient ID: " + patientId);
	        for (Prescription p : prescriptions) {
	            if (p.getPatientId() == patientId) {
	                System.out.println("Medication: " + p.getMedication() + ", Dosage: " + p.getDosage());
	            }
	        }
	    }
}
