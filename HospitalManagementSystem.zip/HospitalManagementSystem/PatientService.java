package com.example.HospitalManagementSystem;
import java.util.HashMap;
import java.util.Map;
public class PatientService {
    private Map<Integer, Patient> patientMap;

    public PatientService() {
        patientMap = new HashMap<>();
    }

    public void registerPatient(Patient patient) {
        patientMap.put(patient.getPatientId(), patient);
    }

    public Patient getPatient(int patientId) {
        return patientMap.get(patientId);
    }

    public void viewPatientRecord(int patientId) {
        Patient patient = patientMap.get(patientId);
        if (patient != null) {
            System.out.println("Patient ID: " + patient.getPatientId());
            System.out.println("Name: " + patient.getName());
            System.out.println("Medical History: " + patient.getMedicalHistory());
        } else {
            System.out.println("Patient not found.");
        }
    }
}
